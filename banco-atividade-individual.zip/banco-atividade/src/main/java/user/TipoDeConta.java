package user;

public enum TipoDeConta {
  Corrente,
  Poupanca,
  Salario,
  Investimento
}
